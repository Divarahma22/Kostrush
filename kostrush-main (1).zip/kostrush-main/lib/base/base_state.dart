class NoState {}
