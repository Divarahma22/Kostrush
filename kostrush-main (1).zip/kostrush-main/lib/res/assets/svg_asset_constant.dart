/// Class ini digunakan untuk menampung semua path asset svg
abstract class SvgAssetConstant {
  SvgAssetConstant._();

  static const String logo = 'assets/svg/kost_rush_logo.svg';
}
