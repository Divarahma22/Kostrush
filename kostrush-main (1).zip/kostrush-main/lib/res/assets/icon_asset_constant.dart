/// Class ini digunakan untuk menampung semua path asset custom icon
abstract class IconAssetConstant {
  IconAssetConstant._();

  static const String google = 'assets/icons/google.svg';
}
