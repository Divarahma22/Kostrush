/// Class ini digunakan untuk menampung semua key storage
abstract class StorageConstant {
  StorageConstant._();

  static const String sessionToken = "session_token";
}
