import 'package:kostrushapp/base/base_argument.dart';
import 'package:kostrushapp/base/base_state.dart';

import '../../../../../../base/base_controller.dart';

class ProfileController extends BaseController<NoArguments, NoState> {
  @override
  void initComponent() {
    // TODO: implement initComponent
  }

  @override
  void onObserve() {
    // TODO: implement onObserve
  }

  @override
  Future<void> onProcess() async {
    // TODO: implement onProcess
  }

  @override
  void disposeComponent() {
    // TODO: implement disposeComponent
  }
}
