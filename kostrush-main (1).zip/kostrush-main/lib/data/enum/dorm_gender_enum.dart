enum DormGenderEnum {
  MALE,
  FEMALE,
  UNISEX,
}
