/// Enum for OTP purpose
enum OtpPusrposeEnum {
  SIGNUP,
  SIGNIN,
  FORGOT_PASSWORD,
  CHANGE_PASSWORD,
}
