enum DormBathEnum {
  shared,
  private,
}
