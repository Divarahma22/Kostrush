enum DormToiletEnum {
  squatToilet,
  sitToilet,
  both,
}
