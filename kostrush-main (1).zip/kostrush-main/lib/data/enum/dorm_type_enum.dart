enum DormTypeEnum {
  REGULAR,
  SUITE,
  PREMIUM,
  VIP,
}
