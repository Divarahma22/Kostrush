package com.yugas.kostrush

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
